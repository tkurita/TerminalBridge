#!perl -w
use strict;

while(<>) {
	print "#$_";
}